%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%    Bacon Pancakes                     %%
%%    María Gracia Hidalgo # 03-36048    %%
%%    Grupo 24                           %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

-   Proyecto Completamente Funcional.

-   Se implementaron todos los predicados definidos en el enunciado del proyecto.

-   Se incluyeron algunos predicados adicionales para ayudar a hacer ciertas verificaciones, así como a otros detalles de la implementación.
